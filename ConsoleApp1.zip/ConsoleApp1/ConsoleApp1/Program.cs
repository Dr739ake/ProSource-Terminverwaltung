﻿using MySqlConnector;

// See https://aka.ms/new-console-template for more information

Console.WriteLine("Hello, World!");

string constr = "Server=cloud.jnsdev.de; User ID=ProSource; Password=4IzGsWTEJk; Database=ProSource;";
using var cn = new MySqlConnection(constr);
cn.Open();
string querry = "select * from Kontakte;";
using var cmd = new MySqlCommand(querry, cn);
using var reader = cmd.ExecuteReader();
while (reader.Read())
{
    Console.WriteLine(reader["name"]);
}